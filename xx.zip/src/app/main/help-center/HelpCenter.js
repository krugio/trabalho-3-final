import { Outlet } from 'react-router-dom';

function HelpCenterApp() {
  return <Outlet />;
}

export default HelpCenterApp;
