import product from './productSlice';
import products from './productsSlice';

export { product, products };
