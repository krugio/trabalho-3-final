export interface Example {
  uid: string;
  title: string;
}

export type Examples = Example[];
