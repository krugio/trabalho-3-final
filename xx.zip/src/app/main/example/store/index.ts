import example from './exampleSlice';
import examples from './examplesSlice';

export { example, examples };
