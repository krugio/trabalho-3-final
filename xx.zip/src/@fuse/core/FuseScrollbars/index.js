import FuseScrollbars from './FuseScrollbars';

export default FuseScrollbars;
