import FusePageCarded from './FusePageCarded';

export default FusePageCarded;
