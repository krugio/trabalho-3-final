# growbase-admin-2
Growbase com fuse 8.0
